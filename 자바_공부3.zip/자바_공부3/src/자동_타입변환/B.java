package 자동_타입변환;

public class B implements A{

}
