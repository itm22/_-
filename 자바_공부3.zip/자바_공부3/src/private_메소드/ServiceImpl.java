package private_메소드;

public class ServiceImpl implements Service {

}
