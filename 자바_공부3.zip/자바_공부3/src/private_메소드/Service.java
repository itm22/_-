package private_메소드;

	public interface Service {


	    default void defaultMethod1() {
	        System.out.println("defaultMethod1 중복 코드A");
	        defaultCommon();
	    }

	    default void defaultMethod2() {
	        System.out.println("defaultMethod2 중복 코드B");
	        defaultCommon();
	    }

	    private void defaultCommon() {
	        System.out.println("defaultMethod 중복 코드A");
	        System.out.println("defaultMethod 중복 코드B");
	    }

	    static void staticMethod1() {
	        System.out.println("staticMethod1 중복 코드C");
	        staticCommon();
	    }

	    static void staticMethod2() {
	        System.out.println("staticMethod2 중복 코드D");
	        staticCommon();
	    }

	    private static void staticCommon() {
	        System.out.println("staticMethod 중복 코드C");
	        System.out.println("staticMethod 중복 코드D");
	    }
}
