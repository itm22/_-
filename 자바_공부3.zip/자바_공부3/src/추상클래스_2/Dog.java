package 추상클래스_2;

public class Dog extends Animal{

	public void sound() {
		System.out.println("멍멍");
	}
}
