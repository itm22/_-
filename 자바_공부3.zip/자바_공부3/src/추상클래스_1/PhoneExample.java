package 추상클래스_1;

public class PhoneExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Phone phone = new Phone
		SmartPhone smartPhone = new SmartPhone("홍길동");
		smartPhone.turnOn();
		smartPhone.internetSearch();
		smartPhone.turnOff();
	}

}
