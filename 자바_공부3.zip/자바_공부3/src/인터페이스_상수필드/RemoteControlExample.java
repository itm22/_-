package 인터페이스_상수필드;

public class RemoteControlExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("리모콘 최대 볼륨: " + RemoteControl.MAX_VOLUME);
		System.out.println("리모콘 최소 볼륨: " + RemoteControl.MIN_VOLUME);
	}
}
