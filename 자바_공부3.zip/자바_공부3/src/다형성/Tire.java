package 다형성;

public interface Tire {
    void roll();
}