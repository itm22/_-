package 다형성;

public class KumhoTire implements Tire {

    public void roll() {
        System.out.println("금호 타이어가 굴러갑니다.");
    }
}