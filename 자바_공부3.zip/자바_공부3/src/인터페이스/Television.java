package 인터페이스;

public class Television implements RemoteControl{
	
	public void turnOn() {
		System.out.println("TV를 켭니다.");
	}
}
