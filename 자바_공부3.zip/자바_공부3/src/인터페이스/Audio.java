package 인터페이스;

public class Audio implements RemoteControl{

	public void turnOn() {
		System.out.println("Audio를 켭니다.");
	}
}
