package 인터페이스;

public class RemoteControlExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		RemoteControl rc;
		
		rc = new Television();
		rc.turnOn();
		
		rc = new Audio();
		rc.turnOn();
	}
}
