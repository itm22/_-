package 다중_인터페이스;

public interface Searchable {
    void search(String url);
}