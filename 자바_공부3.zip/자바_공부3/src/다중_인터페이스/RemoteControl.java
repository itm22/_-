package 다중_인터페이스;

public interface RemoteControl {
    void turnOn();
    void turnOff();
}