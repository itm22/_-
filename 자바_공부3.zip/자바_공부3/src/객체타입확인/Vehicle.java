package 객체타입확인;

public interface Vehicle {
    void run();
}