package 인터페이스_상속;

public interface interfaceB {
    void methodB();
}