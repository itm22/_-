package 인터페이스_상속;

public interface interfaceA {
    void methodA();
}