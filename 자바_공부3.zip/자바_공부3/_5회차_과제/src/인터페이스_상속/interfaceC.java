package 인터페이스_상속;

public interface interfaceC extends interfaceA, interfaceB{
    void methodC();
}