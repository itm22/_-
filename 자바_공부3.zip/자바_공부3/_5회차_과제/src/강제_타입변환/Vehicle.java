package 강제_타입변환;

public interface Vehicle {
    void run();
}