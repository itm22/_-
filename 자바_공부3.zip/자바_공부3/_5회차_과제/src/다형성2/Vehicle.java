package 다형성2;

public interface Vehicle {
    void run();
}