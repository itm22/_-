package 다형성2;

public class Driver {
    void drive(Vehicle vehicle) {
        vehicle.run();
    }
}