package 인터페이스;

public interface RemoteControl {

	void turnOn();
}
