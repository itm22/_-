package 익명객체_2;

public interface RemoteControl {
	void turnOn();
	void turnOff();
}
