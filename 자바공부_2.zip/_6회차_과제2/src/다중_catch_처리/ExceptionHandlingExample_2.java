package 다중_catch_처리;

public class ExceptionHandlingExample_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] array = {"100", "100"};
		
		for(int i = 0; i <= array.length; i++) {
			try {
				int value = Integer.parseInt(array[i]);
				System.out.println("array[" + i +"]: " + value);
			}
			catch(ArrayIndexOutOfBoundsException e) {
				System.out.println("배열 인덱스가 초과됨: " + e.getMessage());
			}
			catch(Exception e) {
				System.out.println("실행에 문제가 있습니다.");
			}
		}
	}

}
